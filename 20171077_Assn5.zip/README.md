# Assignment 5

## Usage:

    python3 pyspark_no.py <Output CSV File Name> <Number of CPUs>

where no = 1, 2, or 3 for Question 1, 2 and 3 respectively.